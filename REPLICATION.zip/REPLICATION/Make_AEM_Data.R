library(readxl)
library(matrixcalc)
library(Rsolnp)
library(MASS)
library(tidyverse)

############ SET DIRECTORY HERE:  #########################

HomeDir <- paste(BaseFolder,"Research_Main/Hansen_Kazemi_Shared/Misspecification_Robust_ID", sep = "")
DataDir <- paste(HomeDir,"/Code/REPLICATION/Data/", sep ="")
CodeDir <- paste(HomeDir,"/Code/REPLICATION/", sep ="")
setwd(CodeDir)

# Fama French factors
FF <- read_csv(paste(DataDir,"F-F_Research_Data_Factors.csv", sep = ""))

# Lev Factors
Lev <- read_csv(paste(DataDir,"AEM_LevFactor.csv", sep = ""))
# Portfolios for testing\
Ports <- read_csv(paste(DataDir,"25_Portfolios_5x5.csv", sep = ""))


# Market
MKT <- FF %>%
  select(Date, MKTRF,RF) %>%
  mutate(MKT = (MKTRF +RF)/ 100,
         RF = RF/100) 

# Make quarterly market and risk-free returns
MKT <- MKT %>%
  mutate(Month1 = as.numeric(substr(Date,5,6)),
         Year = as.numeric(substr(Date,1,4))) %>%
  mutate(Month = 3*(floor(Month1/3.1)+1)) %>% 
  group_by(Year,Month) %>%
  summarize_all(~Reduce("*",1+.)-1) %>%
  ungroup() %>%
  mutate(MKTRF = MKT - RF) %>%
  select(-RF,-Date,-Month1, -MKT)

# Make file in Year, Month, LevFac
Lev <- Lev %>%
  mutate(Month = 3*as.numeric(substr(date,5,6)),
         Year = as.numeric(substr(date,1,4)),
         Lev = LevFactor_original/100) %>%
  select(Year, Month, Lev)

# All Factors
Factors <- Lev %>%
  inner_join(MKT)

# Keep only RF
RF <- FF %>%
  select(Date, RF)

# Portfolio names
NAM <- names(Ports)[2:(N+1)]

# Make quarterly returns for test portfolios
Ports <- Ports %>%
  mutate(Month1 = as.numeric(substr(Date,5,6)),
         Year = as.numeric(substr(Date,1,4))) %>%
  mutate(Month = 3*(floor(Month1/3.1)+1)) %>%
  select(-Date) %>%
  group_by(Year, Month) %>%
  summarize_all(~Reduce("*",1+./100)-1) %>%
  ungroup() %>%
  select(-Month1)

# Quarterly risk free rate
RF <- RF %>%
  mutate(Month1 = as.numeric(substr(Date,5,6)),
         Year = as.numeric(substr(Date,1,4))) %>%
  mutate(Month = 3*(floor(Month1/3.1)+1)) %>%
  select(-Date) %>%
  group_by(Year, Month) %>%
  summarize_all(~Reduce("*",1+./100)-1) %>%
  ungroup() %>%
  select(-Month1)

# Add RF to portfolio data
Ports <- Ports %>%
  inner_join(RF)

# Make Excess Rets
Ports <- Ports %>%
  group_by(Year, Month) %>%
  mutate_all(~ . - RF) %>%
  ungroup()

# Drop RF
Ports <- Ports %>%
  select(-RF)

# All data
AllDat <- Ports %>%
  inner_join(Factors)

saveRDS(AllDat,file.path(DataDir,"Adrian_Etula_Muir_Data.rds"))
