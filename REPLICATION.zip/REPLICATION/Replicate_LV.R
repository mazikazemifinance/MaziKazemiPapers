# Clear workspace
rm(list = ls())
library(readxl)
library(matrixcalc)
library(Rsolnp)
library(tidyverse)
library(MASS)


select <- dplyr::select


############ SET DIRECTORY HERE:  #########################
BaseFolder <- "C:/Users/mazik/ASU Dropbox/Maziar Kazemi/"
HomeDir <- paste(BaseFolder,"Research_Main/Hansen_Kazemi_Shared/Misspecification_Robust_ID", sep = "")
DataDir <- paste(HomeDir,"/Code/REPLICATION/Data/", sep ="")
CodeDir <- paste(HomeDir,"/Code/REPLICATION/", sep ="")
setwd(CodeDir)

###################################
# Data
Data <- readRDS(file.path(DataDir,"Lustig_Verdelhan_Data.rds"))

# number test assets and factors and number cols to skip for dates
N <- 8
K <- 2
Skip <- 1

# Test Assets 
Y <- as.matrix(Data[,(Skip+1):(N+Skip)])
X <- as.matrix(Data[,(N+Skip+1):(N+K+Skip)])

source("KO_Test.R")
KO <- KO_Test(Y,X)



################### FAMA MACBETH ###########################
# Test Asset Names
Nam <- names(Data)[c((Skip+1):(N+Skip))] 

# Make data into long format
LongDat <- Data %>%
  pivot_longer(cols = all_of(Nam))

# Calculate betas (static betas for test)
Bet <- LongDat %>%
  group_by(name) %>%
  do(R = lm(value~Cons +MKT,.)) %>%
  ungroup()

Bet <- Bet %>%
  group_by(name) %>%
  mutate(BCons = R[[1]]$coefficients[2],
         BMKT = R[[1]]$coefficients[3]) %>%
  ungroup() %>%
  select(-R)

# Add betas to data
FB <- LongDat %>%
  left_join(Bet)

# Cross sectional Reg
FB <- FB %>%
  group_by(Date) %>%
  do(R = lm(value ~ BCons +BMKT,.)) %>%
  ungroup()

# FB risk premia
FB <- FB %>% 
  group_by(Date) %>%
  summarize(LCons = R[[1]]$coefficients[2],
            LMKT = R[[1]]$coefficients[3]) %>%
  ungroup()

# Testing significance of risk premia
R1 <- lm(LCons~1,FB)
summary(R1)
R2 <- lm(LMKT~1,FB)
summary(R2)

