# Clear workspace
rm(list = ls())
library(readxl)
library(matrixcalc)
library(Rsolnp)
library(tidyverse)
library(MASS)


select <- dplyr::select


############ SET DIRECTORY HERE:  #########################
BaseFolder <- "C:/Users/mazik/ASU Dropbox/Maziar Kazemi/"
HomeDir <- paste(BaseFolder,"Research_Main/Hansen_Kazemi_Shared/Misspecification_Robust_ID", sep = "")
DataDir <- paste(HomeDir,"/Code/REPLICATION/Data/", sep ="")
CodeDir <- paste(HomeDir,"/Code/REPLICATION/", sep ="")
setwd(CodeDir)

###################################
# Data
Data <- readRDS(file.path(DataDir,"Yogo_Data.rds"))

# number test assets and factors and number cols to skip for dates
N <- 25
K <- 3
Skip <- 2

# Test Assets 
Y <- as.matrix(Data[,(Skip+1):(N+Skip)])
X <- as.matrix(Data[,(N+Skip+1):(N+K+Skip)])

source("KO_Test.R")
KO <- KO_Test(Y,X)



################### FAMA MACBETH ###########################
# Test Asset Names
Nam <- names(Data)[c((Skip+1):(N+Skip))] 

# Make data into long format
LongDat <- Data %>%
  pivot_longer(cols = all_of(Nam))

# Calculate betas (static betas for test)
Bet <- LongDat %>%
  group_by(name) %>%
  do(R = lm(value~0+GrowthNondur+GrowthDur +MKTRF,.)) %>%
  ungroup()

Bet <- Bet %>%
  group_by(name) %>%
  mutate(BND = R[[1]]$coefficients[1],
         BD = R[[1]]$coefficients[2],
         BM = R[[1]]$coefficients[3]) %>%
  ungroup() %>%
  select(-R)

# Add betas to data
FB <- LongDat %>%
  left_join(Bet)

# Cross sectional Reg
FB <- FB %>%
  group_by(Year, Month) %>%
  do(R = lm(value ~ BND+BD +BM,.)) %>%
  ungroup()

# FB risk premia
FB <- FB %>% 
  group_by(Year, Month) %>%
  summarize(LND = R[[1]]$coefficients[2],
            LD = R[[1]]$coefficients[3],
            LM = R[[1]]$coefficients[4]) %>%
  ungroup()

# Testing significance of risk premia
R1 <- lm(LND~1,FB)
summary(R1)
R2 <- lm(LD~1,FB)
summary(R2)
R3 <- lm(LM~1,FB)
summary(R3)

