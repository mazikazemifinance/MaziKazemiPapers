README for Hansen and Kazemi (2024) (Identification of Factor Risk Premia)


#####################################
Folders:

1. Main Replication folder: Contains codes for A) constructing data, B) Running KO test and traditional Fama-MacBeth tests, and C) the KO test function file. The files are named according to the authors of the paper being replicated. 

NOTE: The Lustig and Verdelhan paper has no data creation file because the data can be downloaded ready to test from Adrien Verdelhan's website. For the other two papers, two
	main transformations are done. 1) The factors must be merged with the market return. 2) Both the factors and the test assets must be compounded to a quarterly frequency.
	For the Lustig and Verdelhan data, we saved the data as an RDS file (instead of the raw CSV file).

NOTE: All test assets/market return (except for Lustig and Verdelhan) are downloaded from Ken French's website. 

NOTE: The KO Test function file takes in a TxN matrix of test asset returns and a TxK matrix of factor realizations. The panel must be balanced. The file outputs the estimated rank of the beta matrix (and associated p-values from the Cragg and Donald 1997 test), the rejection/non-rejection of factor risk-premium identification, and associated p-values for the KO test. See the file for more details. 

NOTE: Fama-MacBeth estimates are done at the bottom of the replication files.

2. Data folder: Contains original data downloaded from author websites and Ken French's website as well as the output from the Make_XXX_Data.R files.